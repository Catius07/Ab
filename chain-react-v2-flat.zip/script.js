/* ══════════════════════════════
   CANVAS BG — grille animée
══════════════════════════════ */
(function(){
  const cv = document.getElementById('bgCanvas');
  const ctx = cv.getContext('2d');
  let W,H,cols,rows,cells=[];
  function resize(){
    W=cv.width=window.innerWidth;
    H=cv.height=window.innerHeight;
    const sz=40;cols=Math.ceil(W/sz)+1;rows=Math.ceil(H/sz)+1;
    cells=[];
    for(let r=0;r<rows;r++)for(let c=0;c<cols;c++)
      cells.push({x:c*sz,y:r*sz,a:Math.random(),s:Math.random()*.5+.2});
  }
  function draw(t){
    ctx.clearRect(0,0,W,H);
    ctx.strokeStyle='rgba(255,204,2,0.04)';ctx.lineWidth=1;
    cells.forEach(cell=>{
      const pulse=Math.sin(t/1800+cell.s*6)*.5+.5;
      ctx.globalAlpha=cell.a*pulse*.6;
      ctx.strokeRect(cell.x,cell.y,40,40);
    });
    requestAnimationFrame(draw);
  }
  window.addEventListener('resize',resize);resize();
  requestAnimationFrame(draw);
})();

/* ══════════════════════════════
   GAME ENGINE v2 — LEVEL/ROUND SYSTEM
══════════════════════════════ */
const COMBO_COLORS=['#4fc3f7','#a5d6a7','#fff176','#ffcc02','#ff7043','#e040fb','#ff1744'];
const COMBO_LABELS=['','','','FIRE!','INSANE!','GODLIKE!','UNKILLABLE!'];
const MAX_LIVES=3;
const BASE_DUR=2000;
const STREAK_MAX=7;

/*
  LEVEL SYSTEM:
  - 4 rounds per level
  - Zone sizes (width): 0.38, 0.28, 0.20, 0.13  (indices 0-3)
  - Speed multipliers per round within a level: 1.0, 1.3, 1.65, 2.05
  - Zone movement speeds: 0=none, 1=slow, 2=medium (and beyond)

  Level 1: zone shrinks each round (special), no movement
    round 1: zoneSize[0], speed base
    round 2: zoneSize[1], speed base
    round 3: zoneSize[2], speed base
    round 4: zoneSize[3], speed base

  Levels 2-5 (group A): zone fixed per level, speed increases each round, no movement
    L2: zoneSize[0], L3: zoneSize[1], L4: zoneSize[2], L5: zoneSize[3]

  Levels 6-9 (group B): same as 2-5 but zone moves at moveSpeed[0]
    L6: zoneSize[0], L7: zoneSize[1], L8: zoneSize[2], L9: zoneSize[3]

  Levels 10-13 (group C): same as 2-5 but zone moves at moveSpeed[1]
    L10: zoneSize[0], L11: zoneSize[1], L12: zoneSize[2], L13: zoneSize[3]

  And so on: every 4 levels, moveSpeed index increases by 1.
*/

const ZONE_SIZES = [0.38, 0.28, 0.20, 0.13];
// Speed multipliers for rounds 1-4 within a level
const ROUND_SPEED_MULT = [1.0, 1.3, 1.65, 2.05];
// Zone movement speeds (fraction of track per second)
const ZONE_MOVE_SPEEDS = [0, 0.12, 0.22, 0.32, 0.42];

function getLevelConfig(level) {
  // level is 1-based
  if (level === 1) {
    // Special: zone shrinks each round, fixed speed
    return {
      getZoneSize: (round) => ZONE_SIZES[round - 1],  // round 1-4
      getSpeedMult: (round) => 1.0,
      moveSpeedIdx: 0
    };
  }

  // For levels 2+:
  // group index (0-based): which "group of 4 levels"
  // Level 2 = group 0 idx 0, level 3 = group 0 idx 1, ...
  // Level 6 = group 1 idx 0, ...
  const adjustedLevel = level - 2; // 0-based from level 2
  const groupIdx = Math.floor(adjustedLevel / 4); // 0,1,2,...  (0=levels2-5, 1=levels6-9, 2=levels10-13...)
  const sizeIdx = adjustedLevel % 4;              // 0,1,2,3

  return {
    getZoneSize: (round) => ZONE_SIZES[sizeIdx],
    getSpeedMult: (round) => ROUND_SPEED_MULT[round - 1],
    moveSpeedIdx: groupIdx
  };
}

let G={};
function resetG(){
  G={
    phase:'idle',
    lives:MAX_LIVES,
    level:1,
    round:1,   // 1..4
    animId:null,animStart:0,
    tapped:false,roundActive:false,
    waitTmo:null,
    zone:{start:.31,end:.69},
    score:0, combo:1, bestCombo:1,
    hits:0, misses:0,
    zoneDir:1,      // 1 or -1 for movement direction
    zonePos:0.31,   // current left edge of zone
    zoneWidth:0.38,
    lastFrameTime:0,
    progress:0,
    sharePopupShown:false,
  };
}

/* ── DOM ── */
const SS=n=>document.getElementById(n);
const screens={home:SS('s-home'),cd:SS('s-cd'),game:SS('s-game'),result:SS('s-result')};
function showS(n){Object.values(screens).forEach(s=>s.classList.remove('on'));screens[n].classList.add('on');}

const gLevelRound=SS('gLevelRound');
const gScore=SS('gScore'),gBestCombo=SS('gBestCombo');
const comboBadge=SS('comboBadge'),comboX=SS('comboX');
const streakDots=SS('streakDots');
const trackFill=SS('trackFill'),zoneHL=SS('zoneHL');
const floater=SS('floater');
const sFlash=SS('sFlash');
const livesRow=SS('livesRow');

/* ── Meilleur score local ── */
let bestEver=parseInt(localStorage.getItem('cr_best')||'0');
SS('bestVal').textContent=bestEver;

/* ── BOUTONS ── */
SS('btnPlay').addEventListener('click',startCD);
SS('btnRetry').addEventListener('click',startCD);
SS('btnShareResult').addEventListener('click',shareWA);
SS('tapBtn').addEventListener('click',onTap);
SS('tapBtn').addEventListener('touchstart',e=>{e.preventDefault();onTap();},{passive:false});

// Share popup buttons
SS('btnSharePopupYes').addEventListener('click', doShareAndContinue);
SS('btnSharePopupNo').addEventListener('click', dismissSharePopup);

/* ══ COUNTDOWN ══ */
function startCD(){
  resetG();showS('cd');
  let n=3;
  const cdNum=SS('cdNum');
  cdNum.style.color='var(--c3)';
  cdNum.textContent=n;
  bumpAnim(cdNum);
  const iv=setInterval(()=>{
    n--;
    if(n===0){
      clearInterval(iv);
      cdNum.textContent='GO!';cdNum.style.color='var(--c1)';
      bumpAnim(cdNum);
      Audio.countdown(true);
      setTimeout(initGame,550);
    } else {
      cdNum.textContent=n;bumpAnim(cdNum);
      Audio.countdown(false);
    }
  },750);
}
function bumpAnim(el){el.style.animation='none';void el.offsetWidth;el.style.animation='cd-pop .3s cubic-bezier(.34,1.56,.64,1)';}

/* ══ GAME INIT ══ */
function initGame(){
  showS('game');
  buildStreakDots();
  updateLives();
  updateScoreUI();
  updateComboUI();
  updateLevelRoundUI();
  startRound();
}

/* ══ LEVEL/ROUND UI ══ */
function updateLevelRoundUI(){
  gLevelRound.textContent = 'Niveau ' + G.level + '  —  Round ' + G.round + ' / 4';
}

/* ══ ROUND ══ */
function startRound(){
  if(G.lives<=0){endGame();return;}
  G.tapped=false;G.roundActive=true;G.phase='waiting';

  const cfg = getLevelConfig(G.level);
  G.zoneWidth = cfg.getZoneSize(G.round);

  // Zone starts at center
  G.zonePos = Math.max(0.05, 0.5 - G.zoneWidth / 2);
  G.zoneDir = 1;

  // Speed: base * level factor * round factor
  const levelSpeedBase = 1 + (G.level - 1) * 0.08; // slight base increase per level
  G.currentSpeedMult = cfg.getSpeedMult(G.round) * Math.min(levelSpeedBase, 3.0);
  G.moveSpeedIdx = cfg.moveSpeedIdx;

  updateZoneUI();
  updateLevelRoundUI();

  // Reset track
  trackFill.style.width='0%';
  trackFill.style.filter='none';

  const delay=500+Math.random()*900;
  G.waitTmo=setTimeout(()=>{
    G.phase='running';
    G.animStart=performance.now();
    G.lastFrameTime=G.animStart;
    animate();
  },delay);
}

function updateZoneUI(){
  const left = G.zonePos;
  const right = Math.min(0.95, G.zonePos + G.zoneWidth);
  zoneHL.style.left=(left*100)+'%';
  zoneHL.style.width=((right-left)*100)+'%';
  zoneHL.style.background='rgba(165,214,167,.1)';
  zoneHL.style.borderLeft='2px dashed rgba(165,214,167,.45)';
  zoneHL.style.borderRight='2px dashed rgba(165,214,167,.45)';
}

function animate(){
  if(G.phase!=='running')return;
  const now = performance.now();
  const dt = (now - G.lastFrameTime) / 1000; // seconds
  G.lastFrameTime = now;

  const elapsed=now - G.animStart;
  const dur=BASE_DUR / G.currentSpeedMult;
  const p=Math.min(elapsed/dur,1);
  G.progress = p;
  trackFill.style.width=(p*100)+'%';

  // Move zone if moveSpeedIdx > 0
  const moveSpeed = ZONE_MOVE_SPEEDS[Math.min(G.moveSpeedIdx, ZONE_MOVE_SPEEDS.length-1)];
  if(moveSpeed > 0){
    G.zonePos += G.zoneDir * moveSpeed * dt;
    const maxLeft = 0.95 - G.zoneWidth;
    if(G.zonePos >= maxLeft){ G.zonePos = maxLeft; G.zoneDir = -1; }
    if(G.zonePos <= 0.05){   G.zonePos = 0.05;    G.zoneDir =  1; }
    updateZoneUI();
  }

  const inZone = p >= G.zonePos && p <= (G.zonePos + G.zoneWidth);
  trackFill.style.filter=inZone?'drop-shadow(0 0 8px #a5d6a7)':'none';

  if(p>=1){
    trackFill.style.filter='none';
    if(!G.tapped) handleResult('miss');
    return;
  }
  G.animId=requestAnimationFrame(animate);
}

/* ══ TAP ══ */
function onTap(){
  if(G.phase!=='running'||G.tapped)return;
  G.tapped=true;
  cancelAnimationFrame(G.animId);
  trackFill.style.filter='none';
  const p = G.progress || 0;
  const hit = p >= G.zonePos && p <= (G.zonePos + G.zoneWidth);
  handleResult(hit?'hit':'miss');
}

/* ══ RESULT ══ */
function handleResult(type){
  G.phase='idle';G.roundActive=false;

  if(type==='hit'){
    const center = G.zonePos + G.zoneWidth / 2;
    const p = G.progress || 0;
    const isPerfect = Math.abs(p - center) < 0.04;
    const pts = 100 * G.combo;
    G.score += pts;
    G.hits++;

    if(isPerfect){
      G.score += 50 * G.combo;
      showFloater('PERFECT! +'+(pts+50*G.combo), COMBO_COLORS[Math.min(G.combo-1,6)]);
      Audio.perfect(G.combo);
    } else {
      showFloater('+'+pts, COMBO_COLORS[Math.min(G.combo-1,6)]);
      Audio.hit(G.combo);
    }
    G.combo = Math.min(G.combo+1,10);
    if(G.combo > G.bestCombo) G.bestCombo = G.combo;
    Audio.comboUp(G.combo);
    flash('hit-good');
    spawnParticles(COMBO_COLORS[Math.min(G.combo-2,6)]);
    if(navigator.vibrate)navigator.vibrate(30);

    updateScoreUI();
    updateComboUI();

    // Advance round/level
    advanceProgress();

  } else {
    G.misses++;
    G.lives--;
    const lost = G.combo;
    G.combo = 1;
    if(lost > 2){
      showFloater('COMBO BRISÉ! ×'+lost+' ☠','#ff1744');
      Audio.comboBroken(lost);
    } else {
      showFloater('MISS!','#ff1744');
      Audio.miss();
    }
    flash('hit-miss');
    screens.game.classList.add('shake');
    setTimeout(()=>screens.game.classList.remove('shake'),280);
    if(navigator.vibrate)navigator.vibrate([50,30,50]);
    updateScoreUI();
    updateComboUI();
    updateLives();

    if(G.lives<=0){
      // Show share popup before game over
      setTimeout(()=>showSharePopup(),400);
      return;
    }
  }

  setTimeout(()=>{
    if(G.lives<=0){showSharePopup();return;}
    startRound();
  },820);
}

function advanceProgress(){
  if(G.round < 4){
    G.round++;
  } else {
    // Completed 4 rounds → next level!
    G.level++;
    G.round = 1;
    // Reward: +1 life if < max
    if(G.lives < MAX_LIVES){
      G.lives++;
      updateLives();
      showFloater('+1 VIE ❤️', '#ff7043');
      setTimeout(()=>{}, 0); // flush UI
    } else {
      showFloater('NIVEAU ' + G.level + ' !', '#ffcc02');
    }
    Audio.comboUp(G.level);
  }
}

/* ══ SHARE POPUP (when player loses a life) ══ */
function showSharePopup(){
  const popup = SS('sharePopup');
  popup.classList.add('on');
}

function dismissSharePopup(){
  const popup = SS('sharePopup');
  popup.classList.remove('on');
  if(G.lives<=0){ endGame(); } else { startRound(); }
}

function doShareAndContinue(){
  shareWA();
  const popup = SS('sharePopup');
  popup.classList.remove('on');
  // Grant 1 life as reward
  if(G.lives < MAX_LIVES){
    G.lives++;
    updateLives();
  } else if(G.lives <= 0){
    G.lives = 1;
    updateLives();
  }
  if(G.lives<=0){ endGame(); } else { startRound(); }
}

/* ══ HUD ══ */
function updateLives(){
  for(let i=0;i<3;i++){
    const el=SS('lf'+i);
    el.className='lf'+(i>=G.lives?' gone':'');
  }
}

/* ══ EFFETS ══ */
function showFloater(txt,col){
  floater.textContent=txt;floater.style.color=col;
  floater.classList.remove('pop');void floater.offsetWidth;floater.classList.add('pop');
}

function flash(cls){
  sFlash.className='s-flash '+cls;void sFlash.offsetWidth;
}

function spawnParticles(col){
  const cx=window.innerWidth/2,cy=window.innerHeight*.72;
  for(let i=0;i<14;i++){
    const p=document.createElement('div');p.className='pt';
    p.style.cssText=`background:${col};width:${6+Math.random()*6}px;height:${6+Math.random()*6}px;left:${cx}px;top:${cy}px;`;
    const a=Math.random()*Math.PI*2,d=50+Math.random()*100;
    p.style.setProperty('--dx',Math.cos(a)*d+'px');
    p.style.setProperty('--dy',Math.sin(a)*d+'px');
    document.body.appendChild(p);
    setTimeout(()=>p.remove(),660);
  }
}

/* ══ HUD SCORE/COMBO ══ */
function updateScoreUI(){
  if(gScore){ gScore.textContent=G.score; const ci=Math.min(G.combo-1,6); gScore.style.color=COMBO_COLORS[ci]; }
  if(gBestCombo) gBestCombo.textContent='×'+G.bestCombo;
}

function updateComboUI(){
  if(!comboBadge||!comboX) return;
  const ci=Math.min(G.combo-1,6);
  const col=COMBO_COLORS[ci];
  comboX.textContent='×'+G.combo;
  comboX.style.color=col;
  comboBadge.style.borderColor=col+'44';
  comboBadge.style.background=col+'0d';
  comboBadge.classList.remove('combo-glow');
  void comboBadge.offsetWidth;
  comboBadge.classList.add('combo-glow');
  updateStreakDots();
  if(G.combo>=4&&COMBO_LABELS[Math.min(G.combo-1,6)]){
    const inst=SS('gInst');
    if(inst){ inst.style.opacity='1'; inst.textContent=COMBO_LABELS[Math.min(G.combo-1,6)]; setTimeout(()=>inst.style.opacity='0',700); }
  }
}

function buildStreakDots(){
  if(!streakDots) return;
  streakDots.innerHTML='';
  for(let i=0;i<STREAK_MAX;i++){
    const d=document.createElement('div');d.className='sdot';d.id='sd'+i;
    streakDots.appendChild(d);
  }
}
function updateStreakDots(){
  const ci=Math.min(G.combo-1,6);
  const col=COMBO_COLORS[ci];
  for(let i=0;i<STREAK_MAX;i++){
    const d=SS('sd'+i);
    if(!d) continue;
    d.className='sdot';
    if(i<G.combo-1){d.classList.add('lit');d.style.background=col;}
    else{d.style.background='';}
  }
}

/* ══ END GAME ══ */
function endGame(){
  const popup = SS('sharePopup');
  popup.classList.remove('on');
  showS('result');
  Audio.gameOver();

  const score = (G.level - 1) * 400 + (G.round - 1) * 100;
  if(score>bestEver){
    bestEver=score;
    localStorage.setItem('cr_best',bestEver);
    SS('bestVal').textContent=bestEver;
  }

  SS('resLevel').textContent = 'Niveau ' + G.level;
  SS('resRound').textContent = 'Round ' + G.round + ' / 4 · Score : ' + G.score + ' pts';
  SS('resBest').textContent  = 'Meilleur : Niv. ' + Math.floor(bestEver/400+1);

  let title,bcol;
  if(G.level>=10){title='🏆 LÉGENDAIRE';bcol='#FFD700';}
  else if(G.level>=7){title='🔥 INSANE';bcol='#ff7043';}
  else if(G.level>=4){title='⚡ SOLIDE';bcol='#fff176';}
  else if(G.level>=2){title='👍 PAS MAL';bcol='#a5d6a7';}
  else{title='💀 GAME OVER';bcol='#666';}

  SS('resTitle').textContent=title;
  const vp=SS('verdictPill');
  vp.style.background=bcol+'1a';vp.style.color=bcol;vp.style.border='1px solid '+bcol+'33';
  vp.textContent='Niveau '+G.level+' · Round '+G.round;
}

/* ══ SHARE ══ */
function shareWA(){
  const msg=
`⚡ *CHAIN REACT* — Jeu de réflexes
━━━━━━━━━━━━━━━
🏆 Niveau atteint : *${G.level}*
🎯 Round : *${G.round} / 4*

Tu peux faire mieux ? 👇
${window.location.href}`;
  window.open('https://wa.me/?text='+encodeURIComponent(msg),'_blank');
}

/* ══════════════════════════════
   MOTEUR AUDIO — Web Audio API
══════════════════════════════ */
const Audio = (() => {
  let ctx = null;

  function getCtx() {
    if (!ctx) ctx = new (window.AudioContext || window.webkitAudioContext)();
    if (ctx.state === 'suspended') ctx.resume();
    return ctx;
  }

  function hit(combo) {
    const c = getCtx();
    const t = c.currentTime;
    const baseFreq = 280 + combo * 55;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.connect(gain); gain.connect(c.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(baseFreq, t);
    osc.frequency.exponentialRampToValueAtTime(baseFreq * 1.6, t + 0.08);
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.35, t + 0.01);
    gain.gain.linearRampToValueAtTime(0, t + 0.12);
    osc.start(t); osc.stop(t + 0.15);
  }

  function perfect(combo) {
    const c = getCtx();
    const t = c.currentTime;
    const root = 350 + combo * 40;
    [1, 1.26, 1.5, 2].forEach((ratio, i) => {
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.connect(gain); gain.connect(c.destination);
      osc.type = 'sine';
      osc.frequency.value = root * ratio;
      gain.gain.setValueAtTime(0, t + i * 0.02);
      gain.gain.linearRampToValueAtTime(0.18, t + i * 0.02 + 0.01);
      gain.gain.linearRampToValueAtTime(0, t + i * 0.02 + 0.25);
      osc.start(t + i * 0.02);
      osc.stop(t + i * 0.02 + 0.3);
    });
  }

  function comboUp(level) {
    const c = getCtx();
    const t = c.currentTime;
    const osc = c.createOscillator();
    const gain = c.createGain();
    const dist = c.createWaveShaper();
    const curve = new Float32Array(256);
    for (let i = 0; i < 256; i++) { const x = (i * 2) / 256 - 1; curve[i] = (Math.PI + 80) * x / (Math.PI + 80 * Math.abs(x)); }
    dist.curve = curve;
    osc.connect(dist); dist.connect(gain); gain.connect(c.destination);
    osc.type = 'sawtooth';
    const startF = 180 + level * 30;
    const endF   = startF * (1.5 + level * 0.08);
    osc.frequency.setValueAtTime(startF, t);
    osc.frequency.exponentialRampToValueAtTime(endF, t + 0.18);
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.22, t + 0.02);
    gain.gain.linearRampToValueAtTime(0, t + 0.22);
    osc.start(t); osc.stop(t + 0.25);
  }

  function miss() {
    const c = getCtx();
    const t = c.currentTime;
    const bufLen = c.sampleRate * 0.15;
    const buf = c.createBuffer(1, bufLen, c.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < bufLen; i++) data[i] = Math.random() * 2 - 1;
    const noise = c.createBufferSource();
    noise.buffer = buf;
    const nGain = c.createGain();
    const filter = c.createBiquadFilter();
    filter.type = 'lowpass'; filter.frequency.value = 300;
    noise.connect(filter); filter.connect(nGain); nGain.connect(c.destination);
    nGain.gain.setValueAtTime(0.5, t);
    nGain.gain.linearRampToValueAtTime(0, t + 0.15);
    noise.start(t); noise.stop(t + 0.2);
    const osc = c.createOscillator();
    const oGain = c.createGain();
    osc.connect(oGain); oGain.connect(c.destination);
    osc.type = 'sine';
    osc.frequency.setValueAtTime(180, t);
    osc.frequency.exponentialRampToValueAtTime(60, t + 0.25);
    oGain.gain.setValueAtTime(0.4, t);
    oGain.gain.linearRampToValueAtTime(0, t + 0.28);
    osc.start(t); osc.stop(t + 0.3);
  }

  function gameOver() {
    const c = getCtx();
    const t = c.currentTime;
    [400, 320, 240, 160].forEach((f, i) => {
      const osc = c.createOscillator();
      const gain = c.createGain();
      osc.connect(gain); gain.connect(c.destination);
      osc.type = 'sine';
      osc.frequency.value = f;
      const st = t + i * 0.13;
      gain.gain.setValueAtTime(0, st);
      gain.gain.linearRampToValueAtTime(0.28, st + 0.03);
      gain.gain.linearRampToValueAtTime(0, st + 0.18);
      osc.start(st); osc.stop(st + 0.22);
    });
  }

  function countdown(isGo) {
    const c = getCtx();
    const t = c.currentTime;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.connect(gain); gain.connect(c.destination);
    osc.type = 'sine';
    osc.frequency.value = isGo ? 880 : 440;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.3, t + 0.01);
    gain.gain.linearRampToValueAtTime(0, t + (isGo ? 0.25 : 0.1));
    osc.start(t); osc.stop(t + 0.3);
  }

  function comboBroken(lostCombo) {
    const c = getCtx();
    const t = c.currentTime;
    const osc = c.createOscillator();
    const gain = c.createGain();
    osc.connect(gain); gain.connect(c.destination);
    osc.type = 'sawtooth';
    const startF = 400 + lostCombo * 20;
    osc.frequency.setValueAtTime(startF, t);
    osc.frequency.exponentialRampToValueAtTime(50, t + 0.35);
    gain.gain.setValueAtTime(0.3, t);
    gain.gain.linearRampToValueAtTime(0.3, t + 0.05);
    gain.gain.linearRampToValueAtTime(0, t + 0.38);
    osc.start(t); osc.stop(t + 0.4);
  }

  return { hit, perfect, comboUp, miss, comboBroken, gameOver, countdown };
})();

resetG();

// === PWA AUTO INSTALL + SW ===
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(console.error);
  });
}

let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  setTimeout(async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      deferredPrompt = null;
    }
  }, 1500);
});

/* ══════════════════════════════
   MULTILINGUE AUTO
══════════════════════════════ */
const I18N={
fr:{play:'JOUER',best:'Meilleur score : ',retry:'🔄 Rejouer',wait:'ATTENDS LA ZONE VERTE…'},
en:{play:'PLAY',best:'Best: ',retry:'🔄 Play again',wait:'WAIT FOR THE GREEN ZONE…'},
es:{play:'JUGAR',best:'Mejor: ',retry:'🔄 Jugar otra vez',wait:'ESPERA LA ZONA VERDE…'}
};

function applyLanguage(){
  const lang=((navigator.language||'fr').slice(0,2).toLowerCase());
  const t=I18N[lang]||I18N.fr;
  document.documentElement.lang=lang;
  const play=document.getElementById('btnPlay');
  if(play) play.textContent=t.play;
  const retry=document.getElementById('btnRetry');
  if(retry) retry.textContent=t.retry;
  const best=document.getElementById('bestHome');
  if(best) best.innerHTML=t.best+'<span id="bestVal">'+bestEver+'</span>';
}

window.addEventListener('load',applyLanguage);
